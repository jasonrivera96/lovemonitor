<?php 
	
	/* const BASE_URL = "https://www.dominiocomprado.com"; */
	/* const BASE_URL = "http://localhost/lovemonitor"; */
	const BASE_URL = "https://gestionone.net/lovemonitor";

	//Zona horaria
	date_default_timezone_set('America/Guayaquil');

	//Datos de conexión a Base de Datos
	const DB_HOST = "localhost";
	const DB_NAME = "db_lovemonitor";
	const DB_USER = "root";
	const DB_PASSWORD = "12345";
	const DB_CHARSET = "charset=utf8";

	//Delimitadores decimales/millares
	const SPD = ".";
	const SPM = ",";

	//Simbolo de moneda
	const SMONEY = "$";

 ?>